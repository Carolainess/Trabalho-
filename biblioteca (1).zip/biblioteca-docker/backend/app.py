# API da Biblioteca Simples
#
# Uma API REST pequena para gerenciar o acervo de uma biblioteca:
# cadastrar livros, listar/buscar, editar, excluir e controlar se o
# livro está disponível na estante ou emprestado.
#
# As credenciais e o endereço do banco NÃO ficam fixos no código:
# vêm de variáveis de ambiente, definidas no docker-compose.yml a
# partir do arquivo .env.

import os
import time

import psycopg2
import psycopg2.extras
from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # permite que o frontend (em outra porta/origem) chame a API

DB_HOST = os.environ.get("DB_HOST", "database")
DB_PORT = os.environ.get("DB_PORT", "5432")
DB_NAME = os.environ.get("DB_NAME", "biblioteca")
DB_USER = os.environ.get("DB_USER", "biblioteca_user")
DB_PASSWORD = os.environ.get("DB_PASSWORD", "biblioteca_pass")


def get_connection():
    """
    Abre uma nova conexão com o PostgreSQL.

    Como o contêiner do banco pode ainda estar subindo quando o
    backend inicia, tentamos algumas vezes, com uma pequena pausa
    entre elas, antes de desistir.
    """
    tentativas = 10
    ultimo_erro = None
    for tentativa in range(1, tentativas + 1):
        try:
            return psycopg2.connect(
                host=DB_HOST,
                port=DB_PORT,
                dbname=DB_NAME,
                user=DB_USER,
                password=DB_PASSWORD,
            )
        except psycopg2.OperationalError as erro:
            ultimo_erro = erro
            print(f"[tentativa {tentativa}/{tentativas}] banco ainda não respondeu: {erro}")
            time.sleep(3)
    raise RuntimeError(f"Não foi possível conectar ao banco de dados: {ultimo_erro}")


def livro_para_dict(row):
    return {
        "id": row["id"],
        "titulo": row["titulo"],
        "autor": row["autor"],
        "isbn": row["isbn"],
        "ano_publicacao": row["ano_publicacao"],
        "disponivel": row["disponivel"],
        "data_cadastro": row["data_cadastro"].isoformat() if row["data_cadastro"] else None,
    }


@app.route("/health", methods=["GET"])
def health():
    """Endpoint simples para checar se a API está de pé."""
    return jsonify({"status": "ok"}), 200


@app.route("/livros", methods=["GET"])
def listar_livros():
    """
    Lista os livros. Aceita filtros opcionais via query string:
    - ?busca=texto        -> procura no título ou no autor
    - ?disponivel=true|false -> filtra por disponibilidade
    """
    busca = request.args.get("busca", "").strip()
    disponivel = request.args.get("disponivel")

    query = "SELECT * FROM livros"
    condicoes = []
    valores = []

    if busca:
        condicoes.append("(titulo ILIKE %s OR autor ILIKE %s)")
        valores.extend([f"%{busca}%", f"%{busca}%"])

    if disponivel is not None:
        condicoes.append("disponivel = %s")
        valores.append(disponivel.lower() == "true")

    if condicoes:
        query += " WHERE " + " AND ".join(condicoes)
    query += " ORDER BY titulo ASC"

    conn = get_connection()
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(query, valores)
            livros = [livro_para_dict(row) for row in cur.fetchall()]
        return jsonify(livros), 200
    finally:
        conn.close()


@app.route("/livros/<int:livro_id>", methods=["GET"])
def obter_livro(livro_id):
    conn = get_connection()
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute("SELECT * FROM livros WHERE id = %s", (livro_id,))
            row = cur.fetchone()
        if row is None:
            return jsonify({"erro": "Livro não encontrado."}), 404
        return jsonify(livro_para_dict(row)), 200
    finally:
        conn.close()


@app.route("/livros", methods=["POST"])
def criar_livro():
    dados = request.get_json(silent=True) or {}
    titulo = (dados.get("titulo") or "").strip()
    autor = (dados.get("autor") or "").strip()
    isbn = (dados.get("isbn") or "").strip() or None
    ano_publicacao = dados.get("ano_publicacao") or None

    if not titulo or not autor:
        return jsonify({"erro": "Os campos 'titulo' e 'autor' são obrigatórios."}), 400

    conn = get_connection()
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                """
                INSERT INTO livros (titulo, autor, isbn, ano_publicacao, disponivel)
                VALUES (%s, %s, %s, %s, TRUE)
                RETURNING *
                """,
                (titulo, autor, isbn, ano_publicacao),
            )
            novo_livro = cur.fetchone()
        conn.commit()
        return jsonify(livro_para_dict(novo_livro)), 201
    finally:
        conn.close()


@app.route("/livros/<int:livro_id>", methods=["PUT"])
def atualizar_livro(livro_id):
    dados = request.get_json(silent=True) or {}
    titulo = (dados.get("titulo") or "").strip()
    autor = (dados.get("autor") or "").strip()
    isbn = (dados.get("isbn") or "").strip() or None
    ano_publicacao = dados.get("ano_publicacao") or None

    if not titulo or not autor:
        return jsonify({"erro": "Os campos 'titulo' e 'autor' são obrigatórios."}), 400

    conn = get_connection()
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                """
                UPDATE livros
                SET titulo = %s, autor = %s, isbn = %s, ano_publicacao = %s
                WHERE id = %s
                RETURNING *
                """,
                (titulo, autor, isbn, ano_publicacao, livro_id),
            )
            livro_atualizado = cur.fetchone()
        if livro_atualizado is None:
            conn.rollback()
            return jsonify({"erro": "Livro não encontrado."}), 404
        conn.commit()
        return jsonify(livro_para_dict(livro_atualizado)), 200
    finally:
        conn.close()


def _alterar_disponibilidade(livro_id, disponivel):
    conn = get_connection()
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                "UPDATE livros SET disponivel = %s WHERE id = %s RETURNING *",
                (disponivel, livro_id),
            )
            row = cur.fetchone()
        if row is None:
            conn.rollback()
            return jsonify({"erro": "Livro não encontrado."}), 404
        conn.commit()
        return jsonify(livro_para_dict(row)), 200
    finally:
        conn.close()


@app.route("/livros/<int:livro_id>/emprestar", methods=["PATCH"])
def emprestar_livro(livro_id):
    """Marca o livro como emprestado (indisponível)."""
    return _alterar_disponibilidade(livro_id, disponivel=False)


@app.route("/livros/<int:livro_id>/devolver", methods=["PATCH"])
def devolver_livro(livro_id):
    """Marca o livro como devolvido (disponível na estante)."""
    return _alterar_disponibilidade(livro_id, disponivel=True)


@app.route("/livros/<int:livro_id>", methods=["DELETE"])
def excluir_livro(livro_id):
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("DELETE FROM livros WHERE id = %s", (livro_id,))
            linhas_afetadas = cur.rowcount
        conn.commit()
        if linhas_afetadas == 0:
            return jsonify({"erro": "Livro não encontrado."}), 404
        return jsonify({"mensagem": "Livro excluído com sucesso."}), 200
    finally:
        conn.close()


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
