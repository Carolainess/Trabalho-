// Frontend da Biblioteca Simples.
//
// A página é servida pelo Nginx (contêiner "frontend"), mas quem
// executa este código é o navegador do usuário — por isso ele não
// enxerga a rede interna do Docker e precisa chamar a API pelo
// endereço publicado no host, não pelo nome do serviço "backend".
const API_URL = `http://${window.location.hostname}:5000`;

const formulario = document.getElementById("form-livro");
const campoId = document.getElementById("livro-id");
const campoTitulo = document.getElementById("campo-titulo");
const campoAutor = document.getElementById("campo-autor");
const campoIsbn = document.getElementById("campo-isbn");
const campoAno = document.getElementById("campo-ano");
const tituloFormulario = document.getElementById("titulo-formulario");
const botaoSalvar = document.getElementById("botao-salvar");
const botaoCancelar = document.getElementById("botao-cancelar");
const mensagemStatus = document.getElementById("mensagem-status");

const campoBusca = document.getElementById("campo-busca");
const filtroDisponibilidade = document.getElementById("filtro-disponibilidade");
const corpoTabela = document.getElementById("corpo-tabela");
const listaVazia = document.getElementById("lista-vazia");

let temporizadorBusca = null;

document.addEventListener("DOMContentLoaded", carregarLivros);
formulario.addEventListener("submit", salvarLivro);
botaoCancelar.addEventListener("click", sairDoModoEdicao);
campoBusca.addEventListener("input", () => {
  clearTimeout(temporizadorBusca);
  temporizadorBusca = setTimeout(carregarLivros, 300);
});
filtroDisponibilidade.addEventListener("change", carregarLivros);

async function carregarLivros() {
  const parametros = new URLSearchParams();
  if (campoBusca.value.trim()) {
    parametros.set("busca", campoBusca.value.trim());
  }
  if (filtroDisponibilidade.value) {
    parametros.set("disponivel", filtroDisponibilidade.value);
  }

  try {
    const resposta = await fetch(`${API_URL}/livros?${parametros.toString()}`);
    if (!resposta.ok) throw new Error("Falha ao carregar os livros.");
    const livros = await resposta.json();
    renderizarTabela(livros);
  } catch (erro) {
    exibirMensagem(`Não foi possível carregar o acervo. Verifique se o backend está no ar. (${erro.message})`, "erro");
  }
}

function renderizarTabela(livros) {
  corpoTabela.innerHTML = "";

  if (livros.length === 0) {
    listaVazia.classList.remove("oculto");
    return;
  }
  listaVazia.classList.add("oculto");

  for (const livro of livros) {
    const linha = document.createElement("tr");

    const situacaoClasse = livro.disponivel ? "disponivel" : "emprestado";
    const situacaoTexto = livro.disponivel ? "Disponível" : "Emprestado";

    linha.innerHTML = `
      <td>${escaparHtml(livro.titulo)}</td>
      <td>${escaparHtml(livro.autor)}</td>
      <td>${livro.ano_publicacao ?? "—"}</td>
      <td>${escaparHtml(livro.isbn ?? "—")}</td>
      <td><span class="situacao ${situacaoClasse}">${situacaoTexto}</span></td>
      <td class="acoes-linha">
        ${
          livro.disponivel
            ? `<button class="botao-emprestar" data-acao="emprestar" data-id="${livro.id}">Emprestar</button>`
            : `<button class="botao-devolver" data-acao="devolver" data-id="${livro.id}">Devolver</button>`
        }
        <button class="botao-editar" data-acao="editar" data-id="${livro.id}">Editar</button>
        <button class="botao-excluir" data-acao="excluir" data-id="${livro.id}">Excluir</button>
      </td>
    `;

    corpoTabela.appendChild(linha);
  }

  corpoTabela.querySelectorAll("button[data-acao]").forEach((botao) => {
    botao.addEventListener("click", () => tratarAcaoLinha(botao.dataset.acao, Number(botao.dataset.id)));
  });
}

async function tratarAcaoLinha(acao, id) {
  if (acao === "emprestar") return alterarDisponibilidade(id, "emprestar");
  if (acao === "devolver") return alterarDisponibilidade(id, "devolver");
  if (acao === "excluir") return excluirLivro(id);
  if (acao === "editar") return entrarNoModoEdicao(id);
}

async function alterarDisponibilidade(id, acao) {
  try {
    const resposta = await fetch(`${API_URL}/livros/${id}/${acao}`, { method: "PATCH" });
    if (!resposta.ok) throw new Error("Não foi possível atualizar o livro.");
    exibirMensagem(acao === "emprestar" ? "Empréstimo registrado." : "Devolução registrada.", "sucesso");
    carregarLivros();
  } catch (erro) {
    exibirMensagem(erro.message, "erro");
  }
}

async function excluirLivro(id) {
  if (!confirm("Tem certeza que deseja excluir este livro do acervo?")) return;

  try {
    const resposta = await fetch(`${API_URL}/livros/${id}`, { method: "DELETE" });
    if (!resposta.ok) throw new Error("Não foi possível excluir o livro.");
    exibirMensagem("Livro excluído.", "sucesso");
    if (campoId.value === String(id)) sairDoModoEdicao();
    carregarLivros();
  } catch (erro) {
    exibirMensagem(erro.message, "erro");
  }
}

async function entrarNoModoEdicao(id) {
  try {
    const resposta = await fetch(`${API_URL}/livros/${id}`);
    if (!resposta.ok) throw new Error("Não foi possível carregar este livro.");
    const livro = await resposta.json();

    campoId.value = livro.id;
    campoTitulo.value = livro.titulo;
    campoAutor.value = livro.autor;
    campoIsbn.value = livro.isbn ?? "";
    campoAno.value = livro.ano_publicacao ?? "";

    tituloFormulario.textContent = `Editando: ${livro.titulo}`;
    botaoSalvar.textContent = "Salvar alterações";
    botaoCancelar.classList.remove("oculto");

    document.getElementById("secao-formulario").scrollIntoView({ behavior: "smooth" });
  } catch (erro) {
    exibirMensagem(erro.message, "erro");
  }
}

function sairDoModoEdicao() {
  formulario.reset();
  campoId.value = "";
  tituloFormulario.textContent = "Cadastrar novo livro";
  botaoSalvar.textContent = "Cadastrar livro";
  botaoCancelar.classList.add("oculto");
}

async function salvarLivro(evento) {
  evento.preventDefault();

  const dados = {
    titulo: campoTitulo.value.trim(),
    autor: campoAutor.value.trim(),
    isbn: campoIsbn.value.trim(),
    ano_publicacao: campoAno.value ? Number(campoAno.value) : null,
  };

  const emEdicao = Boolean(campoId.value);
  const url = emEdicao ? `${API_URL}/livros/${campoId.value}` : `${API_URL}/livros`;
  const metodo = emEdicao ? "PUT" : "POST";

  try {
    const resposta = await fetch(url, {
      method: metodo,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(dados),
    });

    const corpo = await resposta.json();
    if (!resposta.ok) throw new Error(corpo.erro || "Não foi possível salvar o livro.");

    exibirMensagem(emEdicao ? "Livro atualizado com sucesso." : "Livro cadastrado com sucesso.", "sucesso");
    sairDoModoEdicao();
    carregarLivros();
  } catch (erro) {
    exibirMensagem(erro.message, "erro");
  }
}

function exibirMensagem(texto, tipo) {
  mensagemStatus.textContent = texto;
  mensagemStatus.className = `mensagem-status ${tipo}`;
  setTimeout(() => {
    mensagemStatus.textContent = "";
    mensagemStatus.className = "mensagem-status";
  }, 4000);
}

function escaparHtml(texto) {
  const div = document.createElement("div");
  div.textContent = texto ?? "";
  return div.innerHTML;
}
