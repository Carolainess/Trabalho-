-- Script de inicialização do banco da Biblioteca.
-- É executado automaticamente pelo PostgreSQL na primeira vez que o
-- contêiner do banco sobe (o Postgres roda tudo que está em
-- /docker-entrypoint-initdb.d/ apenas quando o volume de dados está vazio).

CREATE TABLE IF NOT EXISTS livros (
    id SERIAL PRIMARY KEY,
    titulo VARCHAR(200) NOT NULL,
    autor VARCHAR(150) NOT NULL,
    isbn VARCHAR(20),
    ano_publicacao INTEGER,
    disponivel BOOLEAN NOT NULL DEFAULT TRUE,
    data_cadastro TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Alguns livros de exemplo para a estante já não começar vazia.
INSERT INTO livros (titulo, autor, isbn, ano_publicacao, disponivel) VALUES
    ('Dom Casmurro', 'Machado de Assis', '9788535910663', 1899, TRUE),
    ('O Cortiço', 'Aluísio Azevedo', '9788508108762', 1890, TRUE),
    ('1984', 'George Orwell', '9788535914849', 1949, FALSE),
    ('Grande Sertão: Veredas', 'Guimarães Rosa', '9788503005410', 1956, TRUE)
ON CONFLICT DO NOTHING;
